<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

                  <div class="list-group bg-info" style="height: 90vh;">
                    <a href="index.php" class="list-group-item list-group-item-action bg-info text-center text-white"> Dashboard</a>
                    <a href="profile.php" class="list-group-item list-group-item-action bg-info text-center text-white">Profile</a>
                    <a href="admin.php" class="list-group-item list-group-item-action bg-info text-center text-white"> Administrators</a>
                    <a href="doctor.php" class="list-group-item list-group-item-action bg-info text-center text-white"> Doctors</a>
                    <a href="patient.php" class="list-group-item list-group-item-action bg-info text-center text-white"> Patient</a>
                  </div>
    
</body>
</html>